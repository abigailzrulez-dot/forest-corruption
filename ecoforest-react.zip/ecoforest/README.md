# EcoForest: Heal the Grove (React)

    npm install
    npm run dev

- `src/data.js` – task pool, tips, seeded RNG, tree layout
- `src/scenery.js` – pure functions that return the SVG scenery/vines/trees as strings (same seeded output as the original)
- `src/components/` – Stage (camera, leaves, HUD), Tree, Vines, Butterflies, Board, Gate, InfoModal, ScanModal
- `src/scanner.js` – waste scanner adapter. The 📷 button only appears when `window.claude` exists
  (Claude's artifact runtime). To use it elsewhere, make `getScanner()` return an object with
  `json(prompt, { images, signal })` that calls your own backend.
