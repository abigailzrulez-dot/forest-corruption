import { useCallback, useEffect, useRef, useState } from 'react';
import { TASKS, TIPS, WEEK, weekId } from './data';
import { getScanner } from './scanner';
import Stage from './components/Stage';
import Board from './components/Board';
import Gate from './components/Gate';
import InfoModal from './components/InfoModal';
import ScanModal from './components/ScanModal';

const keyFor = u => 'ecoforest:' + (u || 'guest').toLowerCase();

function loadDone(user) {
  try {
    const sv = JSON.parse(localStorage.getItem(keyFor(user)) || 'null');
    if (sv && sv.w === WEEK) return new Set(TASKS.flatMap((t, i) => (sv.d.includes(t[0]) ? [i] : [])));
  } catch (e) {}
  return new Set();
}
function saveDone(user, done) {
  try { localStorage.setItem(keyFor(user), JSON.stringify({ w: WEEK, d: [...done].map(i => TASKS[i][0]) })); } catch (e) {}
}

export default function App() {
  const [user, setUser] = useState(() => { try { return localStorage.getItem('ecoUser'); } catch (e) { return null; } });
  const [done, setDone] = useState(() => loadDone(user));
  const [gateOpen, setGateOpen] = useState(!user);
  const [modal, setModal] = useState(null);
  const [tipCount, setTipCount] = useState(0);
  const [scanOpen, setScanOpen] = useState(false);
  const [scanner, setScanner] = useState(null);
  const [boardOpen, setBoardOpen] = useState(() => window.innerWidth > 820);
  const [msg, setMsg] = useState({ text: '', on: false });
  const toastTimer = useRef(0);
  const tipOrder = useRef([]);

  const toast = useCallback(text => {
    setMsg({ text, on: true });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setMsg(m => ({ ...m, on: false })), 1800);
  }, []);

  const showTip = useCallback(() => {
    if (!tipOrder.current.length) tipOrder.current = TIPS.map((_, i) => i).sort(() => Math.random() - 0.5);
    const [title, text] = TIPS[tipOrder.current.pop()];
    setTipCount(n => n + 1);
    setModal({ icon: '🍃', title, text, btn: 'Close' });
  }, []);

  useEffect(() => { let live = true; getScanner().then(s => live && setScanner(s)); return () => { live = false; }; }, []);
  useEffect(() => { const id = setTimeout(() => toast('Use ← → to explore the forest'), 700); return () => clearTimeout(id); }, [toast]);
  useEffect(() => { const id = setInterval(() => { if (weekId() !== WEEK) location.reload(); }, 60000); return () => clearInterval(id); }, []);
  useEffect(() => {
    const h = e => { if (e.key === 'Escape') { setModal(null); setScanOpen(false); } };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, []);

  const toggle = i => {
    const next = new Set(done);
    const on = !next.has(i);
    on ? next.add(i) : next.delete(i);
    setDone(next); saveDone(user, next);
    if (on && next.size === TASKS.length) {
      setTimeout(() => setModal({ icon: '🌈', title: 'The forest is healed!', text: 'Every task you did in real life makes a real difference. Keep the habits going and rustle the trees for more tips.', btn: 'Keep exploring' }), 500);
    }
  };
  const reset = () => { const e = new Set(); setDone(e); saveDone(user, e); };
  const enter = name => {
    setUser(name);
    try { localStorage.setItem('ecoUser', name); } catch (e) {}
    setGateOpen(false); setDone(loadDone(name));
    toast('Welcome to your forest, ' + name + '!');
  };
  const signOut = () => { try { localStorage.removeItem('ecoUser'); } catch (e) {} setUser(null); setGateOpen(true); };

  const p = done.size / TASKS.length;
  const status = p === 0 ? 'Red corruption is spreading. Complete tasks to fight it.' : p < 0.5 ? 'The corruption is fading, keep going.' : p < 1 ? 'Green is returning to the grove.' : 'The forest is healed!';
  const daysLeft = (8 - new Date().getDay()) % 7 || 7;

  return (
    <>
      <div className="app">
        <header>
          <h1>🌳 EcoForest</h1>
          <p>Rustle the trees for tips. Do real eco tasks to heal the grove.</p>
        </header>
        <div className={'scene' + (boardOpen ? '' : ' closed')}>
          <Stage progress={p} status={status} count={done.size} total={TASKS.length}
            toastState={msg} showToast={toast} onTip={showTip}
            canScan={!!scanner} onScan={() => setScanOpen(true)}
            boardOpen={boardOpen} onToggleBoard={() => setBoardOpen(o => !o)}
            keysEnabled={!modal && !gateOpen && !scanOpen} />
          <Board tasks={TASKS} done={done} onToggle={toggle} onReset={reset} tipCount={tipCount}
            user={user} onSignOut={signOut} daysLeft={daysLeft} />
        </div>
      </div>
      <ScanModal open={scanOpen} scanner={scanner} onClose={() => setScanOpen(false)} onScanned={n => toast('Items scanned: ' + n)} />
      <Gate open={gateOpen} user={user} onEnter={enter} />
      <InfoModal modal={modal} onClose={() => setModal(null)} />
    </>
  );
}
