export default function Board({ tasks, done, onToggle, onReset, tipCount, user, onSignOut, daysLeft }) {
  return (
    <aside className="board" id="board">
      <h2>🌿 Grove tasks</h2>
      <p className="wk">New tasks every Monday · {daysLeft} day{daysLeft > 1 ? 's' : ''} left</p>
      <p className="wk"><span>{user ? user + '’s forest' : 'Guest'}</span> · <button className="lnk" onClick={onSignOut}>sign out</button></p>
      <ul>
        {tasks.map((t, i) => (
          <li key={t[0]}>
            <button className={'task' + (done.has(i) ? ' done' : '')} aria-pressed={done.has(i)} onClick={() => onToggle(i)}>
              <span className="box">{done.has(i) ? '✓' : ''}</span>
              <span><b>{t[0]}</b><small>{t[1]}</small></span>
            </button>
          </li>
        ))}
      </ul>
      <div className="foot"><span>Tips found: {tipCount}</span><button onClick={onReset}>Start over</button></div>
    </aside>
  );
}
