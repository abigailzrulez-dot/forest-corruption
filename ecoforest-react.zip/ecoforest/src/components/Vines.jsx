import { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { vinesSVG } from '../scenery';

function applyState(v, p) {
  v.querySelectorAll('[data-g]').forEach(e => e.classList.toggle('gone', p >= +e.dataset.g));
  v.querySelectorAll('[data-l]').forEach(e => e.classList.toggle('on', p >= +e.dataset.l));
  const ok = !v.querySelector('[data-g]:not(.gone)');
  v.querySelectorAll('[data-b]').forEach(e => e.classList.toggle('bloom', ok && p >= +e.dataset.b));
}

// The frame of vines is regenerated to fit the stage, then thorns/leaves/flowers react to progress.
export default function Vines({ stageRef, progress }) {
  const ref = useRef(null);
  const pr = useRef(progress); pr.current = progress;
  const [size, setSize] = useState(null);

  useLayoutEffect(() => {
    const st = stageRef.current; let t;
    const measure = () => {
      const w = st.clientWidth, h = st.clientHeight;
      if (w && h) setSize(s => (s && s.w === w && s.h === h ? s : { w, h }));
    };
    measure();
    const ro = new ResizeObserver(() => { clearTimeout(t); t = setTimeout(measure, 120); });
    ro.observe(st);
    return () => { clearTimeout(t); ro.disconnect(); };
  }, [stageRef]);

  const html = useMemo(() => (size ? vinesSVG(size.w, size.h) : ''), [size]);

  // New markup: apply state with transitions off ('nt'), then switch them back on.
  useLayoutEffect(() => {
    const v = ref.current;
    if (!v || !html) return;
    v.classList.add('nt'); applyState(v, pr.current);
    let r2 = 0;
    const r1 = requestAnimationFrame(() => { r2 = requestAnimationFrame(() => v.classList.remove('nt')); });
    return () => { cancelAnimationFrame(r1); cancelAnimationFrame(r2); };
  }, [html]);

  useLayoutEffect(() => { if (ref.current) applyState(ref.current, progress); }, [progress]);

  return <div id="vines" ref={ref} dangerouslySetInnerHTML={{ __html: html }} />;
}
