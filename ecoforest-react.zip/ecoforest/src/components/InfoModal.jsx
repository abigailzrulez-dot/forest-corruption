import { useEffect, useRef } from 'react';

export default function InfoModal({ modal, onClose }) {
  const btn = useRef(null);
  useEffect(() => { if (modal) btn.current?.focus(); }, [modal]);
  if (!modal) return null;
  return (
    <div className="modal on" role="dialog" aria-modal="true" aria-labelledby="mt" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="card">
        <div style={{ fontSize: '2.4rem' }}>{modal.icon}</div>
        <h3 id="mt">{modal.title}</h3>
        <p>{modal.text}</p>
        <button ref={btn} onClick={onClose}>{modal.btn}</button>
      </div>
    </div>
  );
}
