import { useEffect, useRef, useState } from 'react';
import { GRASS } from '../scenery';

export default function Gate({ open, user, onEnter }) {
  const [name, setName] = useState(user || '');
  const [err, setErr] = useState('');
  const input = useRef(null);

  useEffect(() => {
    if (!open) return;
    setName(user || ''); setErr('');
    const id = setTimeout(() => input.current?.focus(), 50);
    return () => clearTimeout(id);
  }, [open, user]);

  const submit = () => {
    const n = name.trim().replace(/\s+/g, ' ');
    if (n.length < 2) { setErr('Please enter at least 2 characters.'); return; }
    onEnter(n);
  };

  return (
    <div className={'gate' + (open ? ' on' : '')} role="dialog" aria-modal="true" aria-labelledby="gt">
      <div className="ggrass" dangerouslySetInnerHTML={{ __html: GRASS }} />
      <div className="gboard">
        <div className="gleaf">🌿</div>
        <h2 id="gt">EcoForest</h2>
        <p>Sign in to tend your own forest and keep your weekly tasks.</p>
        <label htmlFor="gname">Your forest name</label>
        <input id="gname" ref={input} maxLength={20} autoComplete="username" placeholder="e.g. Willow"
          value={name} onChange={e => setName(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); submit(); } }} />
        <div className="gerr" aria-live="polite">{err}</div>
        <button onClick={submit}>Enter my forest</button>
        <small>Saved on this device only.</small>
      </div>
    </div>
  );
}
