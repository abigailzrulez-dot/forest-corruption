import { memo, useEffect, useRef } from 'react';

const COLORS = ['#ffb27a', '#f6a8d0', '#c9b2ff'];

// Rendered inside #world; positions are driven imperatively each frame.
export default memo(function Butterflies({ stageRef, swRef }) {
  const els = useRef([]);

  useEffect(() => {
    const st = stageRef.current, S = () => swRef.current, H = () => st.clientHeight;
    const aim = b => {
      b.tx = Math.max(60, Math.min(S() * 3 - 60, b.x + (Math.random() - 0.5) * S() * 0.9));
      b.ty = H() * (0.28 + Math.random() * 0.47);
      b.sp = 40 + Math.random() * 40;
    };
    const BF = els.current.map((el, i) => {
      const b = { el, x: S() * 3 * (i + 0.5) / els.current.length, y: H() * (0.35 + Math.random() * 0.3), a: Math.random() * 6.28, tx: 0, ty: 0, sp: 50, ph: Math.random() * 9 };
      aim(b); return b;
    });
    let bt = 0, raf = 0;
    const fly = t => {
      const dt = Math.min(0.05, (t - bt) / 1000 || 0.016); bt = t;
      BF.forEach(b => {
        const dx = b.tx - b.x, dy = b.ty - b.y;
        if (Math.hypot(dx, dy) < 26) aim(b);
        let da = Math.atan2(dy, dx) + Math.sin(t / 700 + b.ph) * 0.8 - b.a;
        da = Math.atan2(Math.sin(da), Math.cos(da));
        b.a += da * Math.min(1, dt * 2.4);
        const v = b.sp * (0.65 + 0.35 * Math.sin(t / 430 + b.ph * 2));
        b.x += Math.cos(b.a) * v * dt;
        b.y += Math.sin(b.a) * v * dt + Math.sin(t / 260 + b.ph) * 0.3;
        b.el.style.transform = `translate3d(${b.x.toFixed(1)}px,${b.y.toFixed(1)}px,0) rotate(${(b.a * 57.3 + 90).toFixed(1)}deg)`;
      });
      raf = requestAnimationFrame(fly);
    };
    raf = requestAnimationFrame(fly);
    return () => cancelAnimationFrame(raf);
  }, [stageRef, swRef]);

  return COLORS.concat(COLORS).map((c, i) => (
    <div key={i} className="bf" ref={el => { els.current[i] = el; }}>
      <svg viewBox="0 0 24 20">
        <g fill={c}>
          <g className="wl"><ellipse cx="7" cy="7" rx="7" ry="6" /><ellipse cx="8" cy="14" rx="5" ry="4" opacity=".85" /></g>
          <g className="wr"><ellipse cx="17" cy="7" rx="7" ry="6" /><ellipse cx="16" cy="14" rx="5" ry="4" opacity=".85" /></g>
        </g>
        <rect x="11.2" y="3" width="1.6" height="14" rx=".8" fill="#4b3a2a" />
      </svg>
    </div>
  ));
});
