import { memo, useMemo, useRef } from 'react';
import { TREES } from '../data';
import { treeSVG } from '../scenery';

const TREE_HTML = TREES.map(treeSVG);

export default memo(function Tree({ t, onToast, onDrop }) {
  const ref = useRef(null);
  const n = useRef(0);
  const delay = useMemo(() => (Math.random() * 5).toFixed(1), []);

  const poke = () => {
    const el = ref.current;
    el.classList.remove('rustle'); void el.offsetWidth; el.classList.add('rustle');
    n.current++;
    if (n.current >= 3) { n.current = 0; onDrop(el); } else onToast(`Rustle… ${n.current}/3`);
  };

  return (
    <div ref={ref} className="tree" tabIndex={0} role="button" aria-label="Tree. Click a few times to rustle it."
      style={{
        left: `calc(${t.x}% * var(--sp,1))`, bottom: `${t.y}%`,
        width: `calc(var(--tw,130px)*${t.s.toFixed(2)})`,
        zIndex: Math.round(1000 - t.y * 10), opacity: (1 - t.h * 0.3).toFixed(2), '--dl': `-${delay}s`,
      }}
      onClick={poke}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); poke(); } }}
      dangerouslySetInnerHTML={{ __html: TREE_HTML[t.i] }} />
  );
});
