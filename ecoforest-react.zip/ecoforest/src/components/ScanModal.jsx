import { useEffect, useRef, useState } from 'react';
import { BINS, SMSG, SPROMPT, shrink } from '../scanner';

function Result({ d }) {
  if (!d || d.found === false) {
    return <div className="res"><b>No item spotted</b><small>Try a closer, well-lit photo of one item.</small></div>;
  }
  return (
    <div className="res">
      <b>{String(d.item || 'Unknown item')}</b>
      {d.material && <small>{String(d.material)}</small>}
      <div className="bin">{BINS[d.bin] || BINS.trash}</div>
      {Array.isArray(d.steps) && d.steps.length > 0 && <ul>{d.steps.slice(0, 4).map((s, i) => <li key={i}>{String(s)}</li>)}</ul>}
      {d.tip && <p style={{ margin: '6px 0 0' }}>🌿 {d.tip}</p>}
      <small>Local rules vary, so check your area’s guidelines.</small>
    </div>
  );
}

export default function ScanModal({ open, scanner, onClose, onScanned }) {
  const [blob, setBlob] = useState(null);
  const [preview, setPreview] = useState(null);
  const [out, setOut] = useState(null); // { text } | { data }
  const [busy, setBusy] = useState(false);
  const ctl = useRef(null);
  const count = useRef(0);

  useEffect(() => { if (open) setOut(null); else ctl.current?.abort(); }, [open]);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  const onFile = async e => {
    const f = e.target.files[0];
    if (!f) return;
    setOut(null);
    try { const b = await shrink(f); setBlob(b); setPreview(URL.createObjectURL(b)); }
    catch (err) { setBlob(null); setOut({ text: 'That photo could not be read. Try another one.' }); }
  };

  const scan = async () => {
    if (!blob || !scanner) return;
    ctl.current = new AbortController();
    setBusy(true); setOut({ text: 'Examining your item…' });
    try {
      const data = await scanner.json(SPROMPT, { images: [blob], signal: ctl.current.signal, modelTier: 'quick' });
      setOut({ data }); onScanned(++count.current);
    } catch (e) {
      if (e.code !== 'cancelled') setOut({ text: SMSG[e.code] || 'Something went wrong. Please try again.' });
    } finally { setBusy(false); }
  };

  return (
    <div className={'modal' + (open ? ' on' : '')} role="dialog" aria-modal="true" aria-labelledby="stt" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="card scancard">
        <div style={{ fontSize: '2.2rem' }}>📷</div>
        <h3 id="stt">Waste scanner</h3>
        <p>Take a photo of an item and find out where it belongs.</p>
        <label className="sfilebtn" htmlFor="sfile">Take or choose a photo</label>
        <input id="sfile" type="file" accept="image/*" capture="environment" hidden onChange={onFile} />
        {preview && <img id="sprev" src={preview} alt="Your photo" />}
        <div id="sout" aria-live="polite">{out && out.data !== undefined ? <Result d={out.data} /> : out?.text}</div>
        <div className="srow">
          <button disabled={!blob || busy} onClick={scan}>Scan it</button>
          <button className="ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
