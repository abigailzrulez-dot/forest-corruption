import { memo, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { TREES } from '../data';
import { CLOUDS, LAYERS, PANELS } from '../scenery';
import Tree from './Tree';
import Vines from './Vines';
import Butterflies from './Butterflies';

let leafId = 0;

const Layer = memo(function Layer({ L }) {
  return (
    <div className="lay" data-k={L.k} style={L.key === 'mts' ? { ...L.style, filter: 'blur(1px) var(--fx)' } : L.style}>
      {Array.from({ length: L.n }, (_, k) => {
        const p = PANELS[k][L.key];
        return <div key={k} className={p.cls} dangerouslySetInnerHTML={{ __html: p.html }}
          style={{ position: 'relative', flex: 'none', width: 'auto', height: '100%', aspectRatio: L.ar.toFixed(4) }} />;
      })}
    </div>
  );
});

// Look left/right buttons: press and hold to keep panning.
function NavButton({ step, disabled, className, label, children }) {
  const iv = useRef(0);
  const stop = () => clearInterval(iv.current);
  useEffect(() => stop, []);
  useEffect(() => { if (disabled) stop(); }, [disabled]);
  return (
    <button className={className} aria-label={label} disabled={disabled}
      onPointerDown={() => { step(); stop(); iv.current = setInterval(step, 180); }}
      onPointerUp={stop} onPointerLeave={stop} onPointerCancel={stop}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); step(); } }}>
      {children}
    </button>
  );
}

export default function Stage({ progress, status, count, total, toastState, showToast, onTip, canScan, onScan, boardOpen, onToggleBoard, keysEnabled }) {
  const stageRef = useRef(null);
  const worldRef = useRef(null);
  const mmRef = useRef(null);
  const sw = useRef(900);
  const cam = useRef({ pos: 0.5, target: 0.5, raf: 0 });
  const [tw, setTw] = useState(130);
  const [atLeft, setAtLeft] = useState(false);
  const [atRight, setAtRight] = useState(false);
  const [leaves, setLeaves] = useState([]);

  // Parallax camera: each .lay moves at its own speed, #world at 2x.
  const applyCam = useCallback(() => {
    const x = cam.current.pos * sw.current;
    stageRef.current.querySelectorAll('.lay').forEach(l => { l.style.transform = `translate3d(${(-x * +l.dataset.k).toFixed(1)}px,0,0)`; });
    worldRef.current.style.transform = `translate3d(${(-2 * x).toFixed(1)}px,0,0)`;
    mmRef.current.style.left = (cam.current.pos * 74).toFixed(1) + 'px';
  }, []);

  const tick = useCallback(function step() {
    const c = cam.current;
    c.pos += (c.target - c.pos) * 0.14;
    if (Math.abs(c.target - c.pos) < 0.0005) c.pos = c.target;
    applyCam();
    c.raf = c.pos === c.target ? 0 : requestAnimationFrame(step);
  }, [applyCam]);

  const go = useCallback(d => {
    const c = cam.current;
    c.target = Math.min(1, Math.max(0, c.target + d));
    if (!c.raf) c.raf = requestAnimationFrame(tick);
    setAtLeft(c.target <= 0.001); setAtRight(c.target >= 0.999);
  }, [tick]);

  useEffect(() => () => { cancelAnimationFrame(cam.current.raf); cam.current.raf = 0; }, []);

  useLayoutEffect(() => {
    const st = stageRef.current;
    const rz = () => {
      sw.current = st.clientWidth;
      setTw(Math.round(Math.max(90, Math.min(150, sw.current * 0.15))));
      applyCam();
    };
    const ro = new ResizeObserver(rz);
    ro.observe(st); rz();
    return () => ro.disconnect();
  }, [applyCam]);

  useEffect(() => {
    if (!keysEnabled) return;
    const h = e => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); go(e.key === 'ArrowLeft' ? -0.12 : 0.12); } };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [keysEnabled, go]);

  // Ambient leaf every 5s.
  useEffect(() => {
    const id = setInterval(() => {
      if (document.hidden) return;
      setLeaves(ls => [...ls, { id: ++leafId, amb: true, left: Math.random() * 95 + '%', d: stageRef.current.clientHeight * 0.9 }]);
    }, 5000);
    return () => clearInterval(id);
  }, []);

  // Third rustle drops a leaf from the tree; when it lands, a tip opens.
  const dropLeaf = useCallback(tree => {
    const sr = stageRef.current.getBoundingClientRect(), tr = tree.getBoundingClientRect();
    const top = tr.top - sr.top + tr.height * 0.3, ground = sr.height * 0.88;
    setLeaves(ls => [...ls, { id: ++leafId, left: tr.left - sr.left + tr.width / 2 - 15, top, d: Math.max(60, ground - top) }]);
    showToast('A leaf is falling…');
  }, [showToast]);

  const endLeaf = l => { setLeaves(ls => ls.filter(x => x.id !== l.id)); if (!l.amb) onTip(); };

  return (
    <div id="stage" ref={stageRef} style={{ '--c': 1 - progress, '--tw': tw + 'px' }}>
      <div className="sun" />
      <div className="cloud" style={{ top: 40, left: 0 }} />
      <div className="cloud" style={{ top: 100, left: -300, animationDelay: '-25s', transform: 'scale(.8)' }} />
      {CLOUDS.map((c, i) => <div key={i} className="cloud2" style={{ top: c.top + 'px', '--s': c.s, '--d': c.d + 's', '--dl': '-' + c.dl + 's' }} />)}
      <div className="gloom" />
      {LAYERS.slice(0, 3).map(L => <Layer key={L.key} L={L} />)}
      <div className="ground" />
      <Layer L={LAYERS[3]} />
      <div className="dapple" />
      <div className="blight" /><div className="mist" />
      <div id="world" ref={worldRef}>
        {TREES.map(t => <Tree key={t.i} t={t} onToast={showToast} onDrop={dropLeaf} />)}
        <Butterflies stageRef={stageRef} swRef={sw} />
      </div>
      <Layer L={LAYERS[4]} />
      <div className={'toast' + (toastState.on ? ' on' : '')}>{toastState.text}</div>
      <div className="hud">
        <div className="hudtop"><b>Forest health</b></div>
        <div className="bar"><div className="fill" style={{ width: `${progress * 100}%` }} /></div>
        <div className="hudsub"><span>{status}</span><span>{count} of {total} tasks</span></div>
      </div>
      <NavButton className="nav l" label="Look left" disabled={atLeft} step={() => go(-0.12)}>&#8249;</NavButton>
      <NavButton className="nav r" label="Look right" disabled={atRight} step={() => go(0.12)}>&#8250;</NavButton>
      <div className="mm"><i ref={mmRef} /></div>
      <button className="scanbtn" hidden={!canScan} onClick={onScan}><span aria-hidden="true">📷</span> <span>Scan waste</span></button>
      <button className="tab" aria-controls="board" aria-expanded={boardOpen} onClick={onToggleBoard}>{boardOpen ? 'Hide tasks' : 'Show tasks'}</button>
      {leaves.map(l => (
        <div key={l.id} className="leaf" onAnimationEnd={() => endLeaf(l)}
          style={l.amb ? { opacity: 0.7, left: l.left, top: -20, width: 18, height: 18, '--t': '9s', '--d': l.d + 'px' } : { left: l.left, top: l.top, '--d': l.d + 'px' }}>
          <svg viewBox="0 0 30 30">
            <path d="M4 26C4 11 13 4 27 3c0 14-6 22-20 22" fill={l.amb ? '#9bd56b' : '#f0a23a'} />
            {!l.amb && <path d="M5 25L20 10" stroke="#b86a14" strokeWidth="2" fill="none" />}
          </svg>
        </div>
      ))}
      <Vines stageRef={stageRef} progress={progress} />
      <div className="rays" /><div className="vig" />
    </div>
  );
}
