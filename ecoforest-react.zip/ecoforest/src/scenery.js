import { rnd } from './data';

const BARE={t:`<g class='bare' stroke='#3b2a22' stroke-linecap='round'><path fill='none' stroke-width='3' d='M70 104Q60 82 42 66M70 104Q72 76 70 40M70 104Q82 84 100 70'/><path fill='none' stroke-width='2' d='M60 86Q52 70 40 62M72 80Q82 66 96 58M92 76Q100 64 112 62M70 70Q62 54 56 40M70 60Q80 46 86 34M52 74Q44 64 34 66'/></g>`,
 p:`<g class='bare' stroke='#3b2a22' stroke-linecap='round'><path fill='none' stroke-width='2.5' d='M70 40V138M70 62Q50 64 38 80M70 62Q90 64 102 80M70 86Q46 90 30 106M70 86Q94 90 110 106M70 110Q42 116 26 132M70 110Q98 114 114 130'/></g>`};
export function treeSVG(t){
 const r=rnd(t.i*131+7),k=t.k,f=n=>n.toFixed(1);
 const bl=(n,cx,cy,rx,ry,a,b)=>{let s='';for(let i=0;i<n;i++){const an=r()*6.28,d=Math.sqrt(r());s+=`<circle cx='${f(cx+Math.cos(an)*rx*d)}' cy='${f(cy+Math.sin(an)*ry*d)}' r='${f(a+r()*b)}'/>`}return s};
 const blot=(cx,cy,rx,ry)=>`<g class='blot' filter='url(#s${t.i})'><g fill='#d6293a'>${bl(7,cx,cy,rx,ry,6,7)}</g><g fill='#8f0f24' opacity='.5'>${bl(3,cx,cy,rx*.7,ry*.7,4,5)}</g></g>`;
 let h=`<svg viewBox='0 0 140 190'><defs><filter id='s${t.i}' x='-30%' y='-30%' width='160%' height='160%'><feGaussianBlur stdDeviation='3'/></filter></defs><ellipse cx='70' cy='185' rx='40' ry='6' fill='#274d33' opacity='.3'/>`;
 if(k==='pine'){
  h+=`<rect x='66' y='138' width='8' height='48' fill='#6b4630'/><g class='canopy'>`;
  for(let j=4;j>=0;j--){const ty=8+j*24,by=ty+50,w=20+j*8;let p=`M70 ${ty}L${70+w} ${by}`;for(let q=1;q<=6;q++)p+=`L${f(70+w-q*w/3)} ${by-(q%2?7:0)}`;
   h+=`<path d='${p}Z' fill='#1f5a46'/><path d='M70 ${ty}L${70-w} ${by}L70 ${by-5}Z' fill='#3f9a6a' opacity='.55'/>`}
  h+=blot(70,70,26,50)+BARE.p+`</g>`;
 }else{
  const birch=k==='birch',c=birch?['#3d8a52','#7fc15f','#b5e07a','#dcf29a']:['#255f43','#4a9a5c','#8fcf6e','#c8ee94'];
  h+=birch?`<path d='M64 187L66 76L74 76L76 187Z' fill='#eee9dc'/><g fill='#3a3a38'><rect x='66' y='110' width='5' height='3'/><rect x='70' y='140' width='5' height='3'/><rect x='66' y='160' width='4' height='3'/></g>`
   :`<path d='M56 187Q65 176 65 150L66 100L76 100L77 150Q77 176 86 187Z' fill='#6b4630'/><path d='M66 100L70 100L70 182Q66 176 65 150Z' fill='#9a6a45' opacity='.6'/><path d='M70 125Q55 108 42 92M73 118Q90 102 100 88' stroke='#6b4630' stroke-width='5' fill='none' stroke-linecap='round'/>`;
  const rx=birch?30:48,ry=birch?38:36,cy=birch?58:64;
  h+=`<g class='canopy'><g fill='${c[0]}'>${bl(34,70,cy+8,rx,ry,5,7)}</g><g fill='${c[1]}'>${bl(36,69,cy,rx*.95,ry*.92,5,7)}</g><g fill='${c[2]}' opacity='.85'>${bl(18,62,cy-12,rx*.65,ry*.6,4,6)}</g><g fill='${c[3]}' opacity='.55'>${bl(9,58,cy-20,rx*.4,ry*.35,3,5)}</g>${blot(70,cy,rx*.8,ry*.8)}${BARE.t}</g>`;
 }
 return h+'</svg>';
}
function buildPanel(K){
 const X0=K*1000,R=rnd(4242+K*101),f=n=>n.toFixed(1),pick=a=>a[Math.floor(R()*a.length)];
const mk=(css,vb,inner,cls)=>({cls:'scn '+(cls||''),html:`<svg viewBox='${vb}' preserveAspectRatio='xMidYMax slice' style='width:100%;height:100%;display:block'>${inner}</svg>`});
 const blade=(x,y,h,w,c)=>{const l=(R()-.5)*h*.7;return `<path d='M${f(x)} ${y}Q${f(x+l*.3)} ${f(y-h*.6)} ${f(x+l)} ${f(y-h)}' stroke='${c}' stroke-width='${w}' fill='none' stroke-linecap='round'/>`};
 const G=['#2f7a4c','#3f8f55','#58ad62','#7bc86d'];
 const soft=(n,b,a,c0,c1,fir)=>{
  const q=rnd(70+n*13),fq=[.0018+q()*.0016,.005+q()*.003,.012+q()*.006],ph=[q()*6.3,q()*6.3,q()*6.3],gx=X0+150+R()*700,ga=15+R()*22;
  const y=x=>{const X=x+X0;return b+Math.sin(X*fq[0]*6.283+ph[0])*a+Math.sin(X*fq[1]*6.283+ph[1])*a*.45+Math.sin(X*fq[2]*6.283+ph[2])*a*.15-Math.exp(-(((X-gx)/90)**2))*ga};
  let pts='';for(let x=0;x<=1000;x+=8)pts+=(x?'L':'M')+x+' '+f(y(x));
  let fr='';for(let k=0;k<fir;k++){const x=R()*1000,t=y(x)+4+R()*14,h=9+R()*8,g=pick(['#3f8f55','#4a9a5c','#58ad62','#2f7a4c']);fr+=R()<.4?`<path d='M${f(x-4)} ${f(t)}L${f(x)} ${f(t-h-4)}L${f(x+4)} ${f(t)}Z' fill='${g}'/>`:`<circle cx='${f(x)}' cy='${f(t-h*.5)}' r='${f(h*.55)}' fill='${g}'/><circle cx='${f(x-1.5)}' cy='${f(t-h*.65)}' r='${f(h*.28)}' fill='#a7df86' opacity='.45'/>`}
  return `<defs><filter id='sb' x='-30%' y='-30%' width='160%' height='160%'><feGaussianBlur stdDeviation='6'/></filter><linearGradient id='mg${n}' x1='0' x2='0' y1='0' y2='1'><stop offset='0' stop-color='${c0}'/><stop offset='1' stop-color='${c1}'/></linearGradient></defs><path d='${pts}L1000 300L0 300Z' fill='url(#mg${n})'/><g opacity='.85'>${fr}</g><g class='blot' filter='url(#sb)' fill='#d6293a'>${[0,1,2,3].map(()=>{const x=R()*1000;return `<circle cx='${f(x)}' cy='${f(y(x)+28+R()*20)}' r='${f(22+R()*18)}'/>`}).join('')}</g><path d='${pts}' stroke='#fff' stroke-width='1.2' fill='none' opacity='.35'/>`};
 const mh=`<defs><linearGradient id='mh' x1='0' x2='0' y1='0' y2='1'><stop offset='0' stop-color='#dff3d8' stop-opacity='0'/><stop offset='1' stop-color='#dff3d8' stop-opacity='.6'/></linearGradient></defs>`,mr=y=>`<rect x='0' y='${y}' width='1000' height='${300-y}' fill='url(#mh)'/>`;
 const mts=mk('bottom:36%;height:42%','0 0 1000 300',soft(1,150,34,'#9fd2a8','#cbe9c4',30)+mh+mr(160)+soft(2,192,30,'#7fc291','#b3dcab',70)+mr(205)+soft(3,226,24,'#68b67f','#9ed39a',130));
 const hy=(x,b,a,p)=>{x+=X0;return b+Math.sin(x/130+p)*a+Math.sin(x/57+p*2)*a*.35+Math.sin(x/290+p*.5)*a*.8};
 const hillLayer=(n,b,a,p,c0,c1,trees)=>{
  let pts='';for(let x=0;x<=1000;x+=10)pts+=(x?'L':'M')+x+' '+f(hy(x,b,a,p));
  let ex='';
  for(let i=0;i<7;i++){const cx=R()*1000;ex+=`<ellipse cx='${f(cx)}' cy='${f(hy(cx,b,a,p)+16+R()*40)}' rx='${f(40+R()*50)}' ry='${f(5+R()*7)}' fill='${pick(['#a8dc8c','#8fcf7e','#c4e48e'])}' opacity='.35'/>`}
  [16,32].forEach(o=>{let q='';for(let x=0;x<=1000;x+=20)q+=(x?'L':'M')+x+' '+f(hy(x,b,a,p)+o+Math.sin(x/40)*2);ex+=`<path d='${q}' stroke='#2f7a4c' stroke-width='1.2' fill='none' opacity='.14'/>`});
  for(let i=0;i<trees;i++){const x=R()*1000,y=hy(x,b,a,p)+3+R()*14,h=7+R()*7,g=pick(['#3f8f55','#4a9a5c','#2f7a4c','#58ad62']);ex+=R()<.4?`<path d='M${f(x-3.5)} ${f(y)}L${f(x)} ${f(y-h-3)}L${f(x+3.5)} ${f(y)}Z' fill='${g}'/>`:`<circle cx='${f(x)}' cy='${f(y-h*.5)}' r='${f(h*.55)}' fill='${g}'/><circle cx='${f(x-1.2)}' cy='${f(y-h*.65)}' r='${f(h*.25)}' fill='#a7df86' opacity='.4'/>`}
  for(let i=0;i<90;i++){const x=R()*1000,y=hy(x,b,a,p)+8+R()*(190-b);ex+=`<path d='M${f(x)} ${f(y)}Q${f(x+1)} ${f(y-3)} ${f(x+2)} ${f(y-6)}' stroke='${pick(['#3f8f55','#58ad62','#7bc86d'])}' stroke-width='1.2' fill='none' opacity='.55'/>`}
  for(let i=0;i<26;i++){const x=R()*1000,y=hy(x,b,a,p)+12+R()*(185-b);ex+=`<circle cx='${f(x)}' cy='${f(y)}' r='1.5' fill='${pick(['#fff6d6','#ffd75e','#f6a8d0','#c9b2ff'])}'/>`}
  {let rb='';for(let i=0;i<5;i++){const x=R()*1000;rb+=`<circle cx='${f(x)}' cy='${f(hy(x,b,a,p)+15+R()*30)}' r='${f(25+R()*30)}'/>`}ex+=`<g class='blot' filter='url(#hb)'><g fill='#d6293a'>${rb}</g></g>`}
  return `<defs><filter id='hb' x='-30%' y='-30%' width='160%' height='160%'><feGaussianBlur stdDeviation='6'/></filter><linearGradient id='hg${n}' x1='0' x2='0' y1='0' y2='1'><stop offset='0' stop-color='${c0}'/><stop offset='1' stop-color='${c1}'/></linearGradient><clipPath id='hc${n}'><path d='${pts}L1000 200L0 200Z'/></clipPath></defs><path d='${pts}L1000 200L0 200Z' fill='url(#hg${n})'/><g clip-path='url(#hc${n})'>${ex}</g><path d='${pts}' stroke='#e2f8c8' stroke-width='1.6' fill='none' opacity='.55'/>`};
 const hl=mk('bottom:20%;height:36%','0 0 1000 200',hillLayer(1,78,22,1,'#93d69c','#6fc482',70)+hillLayer(2,113,20,3,'#7ccc8a','#5bb674',50)+hillLayer(3,148,16,5.5,'#68c077','#4fae6a',16));
 let s='';
 for(let row=0;row<2;row++)for(let x=-10;x<1010;x+=(row?16:12)+R()*10){const h=(row?30:24)+R()*34,w=7+R()*6,g=row?pick(['#3f8f55','#4a9a5c','#2f7a4c']):pick(['#5aa77a','#6bb585']);
  s+=R()<.45?`<path d='M${f(x-w)} 100L${f(x)} ${f(100-h)}L${f(x+w)} 100Z' fill='${g}'/>`:`<rect x='${f(x-1.5)}' y='${f(100-h*.35)}' width='3' height='${f(h*.35)}' fill='#6b4630' opacity='.7'/><circle cx='${f(x)}' cy='${f(100-h*.55)}' r='${f(w*1.5)}' fill='${g}'/><circle cx='${f(x-w*.4)}' cy='${f(100-h*.7)}' r='${f(w*.7)}' fill='#a7df86' opacity='.35'/>`}
 const tl=mk('bottom:23%;height:22%','0 0 1000 100',`<g opacity='.95'>${s}</g>`);
 s='';
 [...Array(5)].map(()=>R()*1000).forEach(x=>{const sc=.8+R()*.6,w=34*sc,by=124;
  s+=`<ellipse cx='${f(x)}' cy='${by+4}' rx='${f(w*1.15)}' ry='6' fill='#1f4d33' opacity='.3'/>`;
  const cl=(n,cx,cy,rx,ry,r0,r1,col,op)=>{let o='';for(let i=0;i<n;i++){const an=R()*6.283,d=Math.sqrt(R());o+=`<circle cx='${f(cx+Math.cos(an)*rx*d)}' cy='${f(cy+Math.sin(an)*ry*d)}' r='${f(r0+R()*r1)}'/>`}return `<g fill='${col}' opacity='${op}'>${o}</g>`};
  s+=cl(14,x,by-12*sc,w,13*sc,7*sc,7*sc,'#245f3f',1)+cl(16,x,by-15*sc,w*.9,12*sc,6*sc,7*sc,'#357f50',1)+cl(10,x-w*.15,by-21*sc,w*.6,8*sc,5*sc,5*sc,'#58ad62',.9)+cl(6,x-w*.25,by-25*sc,w*.35,5*sc,3.5*sc,4*sc,'#a7df86',.55);
  for(let i=0;i<4;i++)s+=`<circle cx='${f(x+(R()-.5)*w*1.4)}' cy='${f(by-8*sc-R()*20*sc)}' r='1.8' fill='${pick(['#fff6d6','#f6a8d0','#ffd75e'])}'/>`});
 for(let i=0;i<240;i++)s+=blade(R()*1000,150,18+R()*26,2+R()*1.5,pick(G));
 [0,1,2].map(()=>[R()*1000,122+R()*10]).forEach(([x,y])=>s+=`<ellipse cx='${x}' cy='${y}' rx='28' ry='16' fill='#8f978f'/><ellipse cx='${x-6}' cy='${y-5}' rx='16' ry='7' fill='#b3b9b1'/><path d='M${x-24} ${y-6}Q${x} ${y-22} ${x+24} ${y-6}Q${x} ${y-12} ${x-24} ${y-6}Z' fill='#4a9a5c'/>`);
 [0,1,2].map(()=>R()*1000).forEach(x=>{for(let i=0;i<7;i++){const a=-2.9+i*.45;s+=`<path d='M${x} 148Q${f(x+Math.cos(a)*20)} ${f(148+Math.sin(a)*40)} ${f(x+Math.cos(a)*42)} ${f(148+Math.sin(a)*20)}' stroke='#2f8a58' stroke-width='3' fill='none' stroke-linecap='round'/>`}});
 for(let i=0;i<22;i++){const x=R()*1000,y=118+R()*28,h=14+R()*14,c=pick(['#fff6d6','#ffd75e','#f6a8d0','#c9b2ff','#ffffff']);s+=`<path d='M${f(x)} ${f(y)}V${f(y-h)}' stroke='#2f7a4c' stroke-width='2'/><circle cx='${f(x)}' cy='${f(y-h)}' r='4.5' fill='${c}'/><circle cx='${f(x)}' cy='${f(y-h)}' r='1.8' fill='#e8a317'/>`}
 [0,1,2].map(()=>[R()*1000,138+R()*5]).forEach(([x,y])=>s+=`<rect x='${x-2}' y='${y-9}' width='4' height='10' rx='2' fill='#f3ead4'/><path d='M${x-9} ${y-8}Q${x} ${y-22} ${x+9} ${y-8}Z' fill='#d9a05b'/><circle cx='${x-3}' cy='${y-12}' r='1.3' fill='#fff3d6'/><circle cx='${x+3}' cy='${y-14}' r='1.3' fill='#fff3d6'/>`);
 const gb=mk('bottom:0;height:26%','0 0 1000 150',s);
 s='';
 for(let i=0;i<260;i++){const x=R()*1000;s+=blade(x,100,22+R()*34*(.4+Math.abs(x-500)/500),2.5+R()*2,pick(['#2a6e45','#347f4e','#4a9a5c','#5fb06a']))}
 const fg=mk('bottom:0;height:14%','0 0 1000 100',s,'front');
 return{mts,hl,tl,gb,fg};
}

export function vinesSVG(W,H){
 const R=rnd(777),f=n=>n.toFixed(1),pick=a=>a[Math.floor(R()*a.length)],m=13,rad=34,P=[];
 const seg=(x0,y0,x1,y1)=>{const n=Math.max(1,Math.round(Math.hypot(x1-x0,y1-y0)/6));for(let i=0;i<n;i++)P.push([x0+(x1-x0)*i/n,y0+(y1-y0)*i/n])};
 const arc=(cx,cy,a0)=>{const n=Math.round(rad*1.57/6);for(let i=0;i<n;i++){const a=a0+1.5708*i/n;P.push([cx+Math.cos(a)*rad,cy+Math.sin(a)*rad])}};
 seg(m+rad,m,W-m-rad,m);arc(W-m-rad,m+rad,-1.5708);
 seg(W-m,m+rad,W-m,H-m-rad);arc(W-m-rad,H-m-rad,0);
 seg(W-m-rad,H-m,m+rad,H-m);arc(m+rad,H-m-rad,1.5708);
 seg(m,H-m-rad,m,m+rad);arc(m+rad,m+rad,3.1416);
 const N=P.length,tn=P.map((p,i)=>{const a=P[(i+N-1)%N],b=P[(i+1)%N],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;return[dx/l,dy/l]});
 let dk='',gv='',th='',fl='',lf='';
 [1,-1].forEach((sg,si)=>{
  const pts=P.map((p,i)=>{const t=tn[i],o=sg*Math.sin(i*6/42)*4.5+Math.sin(i*6/150)*3;return[p[0]-t[1]*o,p[1]+t[0]*o]});
  const d='M'+pts.map(p=>f(p[0])+' '+f(p[1])).join('L')+'Z';
  dk+=`<path d='${d}' stroke='#4b1030' stroke-width='4.5' fill='none' stroke-linejoin='round'/><path d='${d}' stroke='#8a2a50' stroke-width='1' fill='none' opacity='.5'/>`;
  gv+=`<path d='${d}' stroke='#3a8550' stroke-width='4.5' fill='none' stroke-linejoin='round'/><path d='${d}' stroke='#8fd67a' stroke-width='1.2' fill='none' opacity='.6'/>`;
  for(let i=0;i<N;i++){
   const p=pts[i],t=tn[i],nx=-t[1],ny=t[0],q=(a,b)=>`${f(p[0]+nx*a+t[0]*b)} ${f(p[1]+ny*a+t[1]*b)}`;
   if((i+si*2)%4===0){const ts=(i%8<4)?4:-4;
    th+=`<path class='th' data-g='${f(.06+R()*.56)}' d='M${q(0,-3.5)}Q${q(7,0)} ${q(11,ts)}Q${q(3,ts*.7)} ${q(0,3.5)}Z' fill='#7a1232'/>`}
   if((i+si*23)%41===6){const cv=`<path d='M${q(0,0)}C${q(10,2)} ${q(17,12)} ${q(9,16)}S${q(2,10)} ${q(5,8)}' fill='none' stroke-width='1.6' stroke-linecap='round'`;dk+=cv+` stroke='#4b1030'/>`;gv+=cv+` stroke='#4fa05f'/>`}
   if((i+si*5)%9===4){const a=Math.atan2(ny,nx)*57.3+((i%2)?-35:35);
    lf+=`<g transform='translate(${f(p[0])} ${f(p[1])}) rotate(${f(a)})'><g class='lf' data-l='${f(.1+R()*.52)}'><path d='M0 0Q7 -6 17 0Q7 6 0 0Z' fill='${pick(['#4fa05f','#58ad62','#6dbb6a'])}'/><path d='M1 0H14' stroke='#2f7a4c' stroke-width='.8' opacity='.7'/></g></g>`}
   if((i+si*10)%20===3){
    const c=pick(['#fff6d6','#ffd75e','#f6a8d0','#c9b2ff','#ffffff','#ffb27a']),r=6+R()*4;let pe='';
    for(let k=0;k<5;k++){const an=k*1.2566;pe+=`<circle cx='${f(Math.cos(an)*r*.7)}' cy='${f(Math.sin(an)*r*.7)}' r='${f(r*.55)}'/>`}
    fl+=`<g transform='translate(${f(p[0]+nx*4)} ${f(p[1]+ny*4)})'><g class='fl' data-b='${f(.63+R()*.37)}'><g fill='${c}'>${pe}</g><circle r='${f(r*.35)}' fill='#ffc93c'/></g></g>`}
  }
 });
 return `<svg viewBox='0 0 ${W} ${H}' preserveAspectRatio='none'><g class='dk'>${dk}</g><g class='gv'>${gv}</g><g>${lf}</g><g>${th}</g><g>${fl}</g></svg>`;
}

export const GRASS=(()=>{const R2=rnd(99);let g='';for(let i=0;i<170;i++){const x=R2()*1000,h=24+R2()*50,l=(R2()-.5)*30;g+=`<path d='M${x.toFixed(1)} 100Q${(x+l*.3).toFixed(1)} ${(100-h*.6).toFixed(1)} ${(x+l).toFixed(1)} ${(100-h).toFixed(1)}' stroke='${['#2a6e45','#347f4e','#4a9a5c','#7bc86d'][i%4]}' stroke-width='${(2.5+R2()*2).toFixed(1)}' fill='none' stroke-linecap='round'/>`}return `<svg viewBox='0 0 1000 100' preserveAspectRatio='none'>${g}</svg>`})();

export const CLOUDS=(()=>{const R=rnd(2024);return Array.from({length:5},()=>({top:50+R()*130,s:(.6+R()*.6).toFixed(2),d:Math.round(90+R()*70),dl:Math.round(R()*120)}))})();
export const LAYERS=[
 {key:'mts',style:{bottom:'36%',height:'42%'},ar:1000/300,n:3,k:.4},
 {key:'hl',style:{bottom:'20%',height:'36%'},ar:5,n:3,k:.8},
 {key:'tl',style:{bottom:'23%',height:'22%'},ar:10,n:4,k:1.4},
 {key:'gb',style:{bottom:'0',height:'26%'},ar:1000/150,n:4,k:2},
 {key:'fg',style:{bottom:'0',height:'14%',zIndex:200},ar:10,n:5,k:2.6}];
export const PANELS=[0,1,2,3,4].map(buildPanel);
