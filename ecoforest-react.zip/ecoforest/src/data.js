export function rnd(s){return()=>(s=s*16807%2147483647)/2147483647}
export const POOL=[
["Make an eco-brick","Stuff a clean, dry plastic bottle with soft plastic wrappers until it is rock hard."],
["Take a 5-minute shower","Set a timer. Short showers save litres of water and energy."],
["Tap off while brushing","Turn the water off while you scrub. Back on to rinse."],
["Reuse leftover water","Water plants with cooking water or the cup you didn't finish."],
["Carry a reusable bag or bottle","Skip one single-use bag or bottle today."],
["Unplug idle devices","Chargers and gadgets sip power even when nothing is connected."],
["Compost food scraps","Start or feed a compost bin instead of binning peels and cores."],
["Sort your recycling","Rinse containers and check local rules for what goes where."],
['Skip meat for one meal','Swap one meal for a plant-based one.'],
['Wash clothes cold','Cold cycles use far less energy.'],
['Hang laundry to dry','Skip the dryer for one load.'],
['Use a refillable cup','Say no to a disposable coffee cup.'],
['Fix a leaky tap','A dripping tap can waste thousands of litres a year.'],
['Plant a seed or sapling','Grow something in a pot, yard or community garden.'],
['Walk, bike or take transit','Swap one car trip for a greener one.'],
['Pick up litter','Collect ten pieces of trash on a walk.'],
['Repair instead of replace','Mend a tear, a button or a broken item.'],
['Switch off unused lights','Or swap one old bulb for an LED.'],
['Have a no-buy day','Skip any non-essential purchase today.'],
['Plan meals to cut food waste','Check the fridge, then write a shopping list.'],
['Reuse scrap paper','Use both sides before recycling.'],
['Unsubscribe from junk mail','Cancel one paper catalogue or flyer.'],
['Donate or swap an item','Give something you no longer use a second life.'],
['Set out a pollinator water dish','A shallow dish with pebbles helps bees and butterflies.']];
export function weekId(){const n=new Date();return Math.floor((Date.UTC(n.getFullYear(),n.getMonth(),n.getDate())-Date.UTC(1970,0,5))/6048e5)}
export const WEEK=weekId();
export const TASKS=(()=>{const r=rnd(WEEK*7919+13),a=POOL.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a.slice(0,8)})();
export const TIPS=[
["Mind your water","Fixing a dripping tap can save thousands of litres a year. Check taps and toilets for slow leaks."],
["Eco-bricks lock up plastic","Packing clean soft plastic into bottles keeps it out of waterways and can be used to build garden benches."],
["Eat a little less meat","Even one or two plant-based meals a week lowers your food's carbon and water footprint."],
["Wash cold, hang dry","Most of a washing machine's energy heats the water. Cold cycles and a clothesline cut your bill and emissions."],
["Buy less, repair more","Sewing a button or fixing a zip keeps clothes out of landfill and saves the resources used to make new ones."],
["Plant for pollinators","Native flowers feed bees and butterflies. Even a balcony pot helps."],
["Shop with a list","Roughly a third of food is wasted. Planning meals means less rotting food and less methane."],
["Rinse, don't wash twice","Collect cold shower warm-up water in a bucket and use it for plants or flushing."],
["Choose lights wisely","LED bulbs use far less power than old bulbs. Switch off lights when you leave a room."],
["Walk, bike or share the ride","Short trips on foot or bike cut emissions and air pollution on your street."],
["Skip the junk mail","Unsubscribe from paper catalogues and flyers to save paper, ink and trees."],
["Say no to microplastics","Use a washing bag that catches synthetic fibres and choose natural fabrics when you can."]];
export const TREES=(()=>{const r=rnd(31),a=[];let i=0;
 [[.35,13,17,.62,.78,20],[.12,9,13,.9,1.08,14],[0,3,8,1.15,1.45,9]].forEach(([h,y0,y1,s0,s1,n])=>{for(let k=0;k<n;k++)a.push({x:(k+.15+r()*.7)/n*100,y:y0+r()*(y1-y0),s:s0+r()*(s1-s0),i:i++,h,k:['oak','oak','pine','pine','birch','oak','pine'][Math.floor(r()*7)]})});return a})();
